package docComments;

import java.util.ArrayList;
import java.util.Scanner;

public class userInputApp 
{
	public static void main(String[] args) 
	{
		
	}
}
