package docComments;

import java.util.ArrayList;
import java.util.Scanner;
/**
 * This java document gets a users input and completes requests based on what choice the users make
 * @author manya
 *
 */
public class laptopList 
{
	public static void main(String[] args) 
	{

		ArrayList<laptopQualities> laptops = new ArrayList<laptopQualities>();

		laptops.add(new laptopQualities("Apple", 2015, "Macbook"));
		laptops.add(new laptopQualities("Microsoft", 2019, "Surface Pro"));
		laptops.add(new laptopQualities("Google", 2021, "Chromebook"));
		laptops.add(new laptopQualities("Lenovo", 2018, "Idea Pad"));

		Scanner q = new Scanner(System.in);

		while (true) {
			System.out.println("Enter a number from 1 - 6" + "\n" + "1. Show all laptops" + "\n" + "2. Add a laptops"
					+ "\n" + "3. Find a laptops" + "\n" + "4. Delete a laptops" + "\n" + "5. Number of laptops" + "\n"
					+ "6. Exit");

			int userNum = q.nextInt();

			if (userNum == 6) {
				break;
			} else if (userNum == 1) {
				printAllLaptops(laptops);
			}else if (userNum == 2) {
				enterNewLaptop(laptops, q);
			}else if (userNum == 3) {
				findLaptopByID(laptops, q);
			}else if (userNum == 4) {
				removeLaptopById(laptops, q);
			}else if (userNum == 5) {
				System.out.println("The number of laptops is " + laptops.size() + "\n");
			}else {
				System.out.println("You did not choose a number between 1 and 6 please try again");
			}

		}

	}

	/**
	 * @param laptops
	 * @param q
	 */
	protected static void removeLaptopById(ArrayList<laptopQualities> laptops, Scanner q) {
		System.out.println("What is the Laptop's Id number? ");
		int inputId = q.nextInt();

		for (int i = 0; i < laptops.size(); i++) {
			if (laptops.get(i).getLaptopId() == inputId) {
				System.out.println(laptops.get(i).printLaptop() + " has been removed");
				laptops.remove(i);
				break;
			}
			else
				System.out.println("There are no laptop under this Id, please give the Id of the laptop you would like to remove");
		}
	}

	/**
	 * @param laptops
	 * @param q
	 */
	protected static void findLaptopByID(ArrayList<laptopQualities> laptops, Scanner q) {
		System.out.println("What is the Laptop's Id number? ");
		int inputId = q.nextInt();

		for (int i = 0; i < laptops.size(); i++) {
			if (laptops.get(i).getLaptopId() == inputId) {
				System.out.println(laptops.get(i).getBrand() + " " + laptops.get(i).getMake() + " id: "
						+ laptops.get(i).getLaptopId() + "\n");

			}

			if (laptops.size() - 1 == i && laptops.get(i).getLaptopId() != inputId) {
				System.out.println("There is no laptop under that id");
			}
		}
	}

	/**
	 * @param laptops
	 * @param q
	 */
	protected static void enterNewLaptop(ArrayList<laptopQualities> laptops, Scanner q) 
	{
		System.out.println("Enter the Brand: ");
		String brand = q.nextLine();

		q.nextLine();
		System.out.println("Enter the year: ");
		int year = q.nextInt();

		q.nextLine();
		System.out.println("Enter the Make: ");
		String make = q.nextLine();

		laptops.add(new laptopQualities(brand, year, make));
	}

	/**
	 * @param laptops
	 */
	protected static void printAllLaptops(ArrayList<laptopQualities> laptops)
	{
		for (int j = 0; j < laptops.size(); j++) 
		{
			System.out.println(laptops.get(j).printLaptop());
		}
	}
}
